<!DOCTYPE html>
<html lang="en">
   <head>
       <meta charset="utf-8" />
       <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
       <!-- Start Meta Ads -->
       <meta name="platform" content="desktop" />
       <meta name="site_name" content="streaming" />
       <!-- End Meta Ads -->
       <title>Live Streaming</title>
       <style>
           body {
               margin:0;
               padding:0;
           }
       </style>
       <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	   
       <div class="areatop">
           <div class="areavideo">
               <article>
                   <div class="container-video">

                            <script>
                                var video_title = 'Desktop - Live Streaming';
                            </script>

                            <div id="stream" class="fp-slim fp-mute">
                                <link rel="stylesheet" href="">
                                    <script src="https://cdn1.mbahnunungonline.net/detikVideo/detikVideo.core.js?v=fcf1561ab">
                                    
                                    {
                                        target      : 'stream',
                                        title       : video_title,
                                        autoplay    : false,
                                        mute        : false,
                                        live        : true,
                                        imageUrl    : 'https://scontent-sin2-2.xx.fbcdn.net/v/t1.0-9/10968481_10153037208209190_2235291833134020224_n.jpg?_nc_cat=107&_nc_ht=scontent-sin2-2.xx&oh=1b306e3487cc4c152b2276a9cb5e9848&oe=5D45B2CE?v=8.3.2',
                                        videoUrl    : 'http://202.93.133.3:1935/svr2/tic.com.stream_720p/playlist.m3u8',
                                        adRules     : '',
                                        channel     : 'livestreaming',
                                        features    : {
                                            loadByDiv       : true,
                                            smartAutoplay   : true,
                                        }
                                    }
                                    </script>
                                    

                            </div>

                    </div>
                </article>
            </div>
        </div>
   </body>
</html>

