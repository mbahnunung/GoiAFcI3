<!DOCTYPE html>
<html lang="en">
   <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
       
       <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
       <!-- Start Meta Ads -->
       <meta name="platform" content="desktop" />
       <meta name="site_name" content="streaming" />
       <!-- End Meta Ads -->
       <title>Live Streaming</title>
       <style>
           body {
               margin:0;
               padding:0;
               overflow: hidden;
           }
       </style>
       <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
       <script src="https://cdn1.mbahnunungonline.net/v3/hola_player/hola_player.js"></script>
	   
       <div align="center">
        <video poster="https://4.bp.blogspot.com/-BJpbb1Wxc8M/XMK1ZG2aucI/AAAAAAAALVw/92dEplccyMUliAlaktqK7ka0xUyjOI3nQCLcBGAs/s1600/TV_Okey_RTM.png?v=8.3.2" id="video-player" class="video-js vjs-fluid vjs-default-skin" height="340" width="596" controls autoplay>
        <source src="http://rtm1mobile.secureswiftcontent.com/Origin02/ngrp:RTM2/playlist.m3u8" type="application/x-mpegURL" />
       </video>
     <script>
      window.hola_player();
     </script>
     </div>
   </body>
</html>