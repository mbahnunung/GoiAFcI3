<!DOCTYPE html>
<html lang="en">
<head>
    <title>Live Streaming</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="initial-scale = 1.0, user-scalable = no, width=device-width, height=device-height, maximum-scale=1.0">
    <meta name="apple-mobile-web-app-capable" content="yes" />
    <meta name="description" content="Live Streaming" />
    <link rel="stylesheet" href="//vjs.zencdn.net/5.4.6/video-js.min.css?v=1.8">
    <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
<style>
           body {
               margin:0;
               padding:0;
               overflow: hidden;
               background:#2f3542;
           }
       </style>
<center>
<script>
        var video_title = "Live Streaming";
    </script>
 <div id="video" class="fp-slim fp-mute"></div>
<script src="https://cdn1.mbahnunungonline.net/js/nnVideo.core.js?v=98c76261ffc">
        {
            target      : 'video',
            title       : 'Live Streaming',
            autoplay    : false,
            mute        : false,
            live        : true,
            imageUrl    : "../img/thumbs/Mayapada_TV.png?v=8.3.2?v=8.3.2",
            channel     : "livestreaming",
            videoUrl    : "https://livetvhooq.akamaized.net:443/b2fec42490a14386ac53eafa47f590a7/ap-southeast-1/5493668622001/profile_0/chunklist.m3u8?hdnts=st=1573597923~exp=9007200828338914~acl=/b2fec42490a14386ac53eafa47f590a7/*/profile_0/chunklist.m3u8*~hmac=15a17e5b10bc2f36b6fbe927f137fff5a759fcc501c3d6712d5976a51a9b45ea",
            adRules     : '',
            features: {
                loadByDiv:true,
                smartAutoplay: true            }
        }
        </script>
</center>
</body>
</html>
