<!DOCTYPE html>
<html lang="en">
    <head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
        <title>Live Streaming</title>
        
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="initial-scale = 1.0, user-scalable = no, width=device-width, height=device-height, maximum-scale=1.0">
        <meta name="apple-mobile-web-app-capable" content="yes"/>
        <meta name="description" content="Live Streaming" />

        <link rel="stylesheet" href="//releases.flowplayer.org/7.2.7/skin/skin.css?v=1.8">
        <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>

            <style>
           body {
               margin:0;
               padding:0;
               overflow: hidden;
           }
       </style>
    <script>
        var video_title = "Live Streaming";
    </script>
        <div id="video" class="fp-slim fp-mute"></div>
        <script src="https://cdn1.mbahnunungonline.net/nnVideo/nnVideo.core.js?v=9f75c5bc">
        {
            target      : 'video',
            title       : 'Live Streaming',
            autoplay    : false,
            mute        : false,
            live        : true,
            imageUrl    : 'https://4.bp.blogspot.com/-N0ZrPxFJPYs/W9ILcOMkTuI/AAAAAAAAJ18/oBB_VumAKnc5RXykxJJo0XjSwXpdmOckQCLcBGAs/s1600/tvone-tv-stream-60883f.jpg?v=8.3.2',
            channel     : 'livestreaming',
            videoUrl    : 'https://kastproxy-us.herokuapp.com/http://rr2.dens.tv/s/s105/01.m3u8',
            adRules     : '',
            features: {
                loadByDiv:true,
                smartAutoplay: true            }
        }
        </script>
        </body>
</html>
