<!DOCTYPE html>
<head>
<title>Live Stream</title>
<meta name="robots" content="noindex"/>
<style>
body{margin:0;padding:0;}
.clear{clear:both;}
</style>
  <script src="https://code.jquery.com/jquery-3.2.1.min.js"></script>
  <script type='text/javascript' src='//cdn.jsdelivr.net/jquery.marquee/1.4.0/jquery.marquee.min.js'></script>
  <script type="text/javascript" src="https://cdnjs.cloudflare.com/ajax/libs/clappr/0.3.3/clappr.min.js"></script>
  <script type="text/javascript" src="https://warningfm.github.io/v3/js/plugin.js"></script>
  <link rel="stylesheet" type="text/css" href="https://tv.mbahnunungonline.net/embed/player/plugin.css">
  <script type="text/javascript" src="https://warningfm.github.io/v3/js/clytpl.js"></script>
  <script type="text/javascript" src="//cdn.jsdelivr.net/gh/clappr/clappr-level-selector-plugin@latest/dist/level-selector.min.js"></script>

<body>
<div id='player'></div>
<script>
//<![CDATA[
function getQueryParam(param) {
var result =  window.location.search.match(new RegExp("(\\?|&)" + param + "(\\[\\])?=([^&]*)")); return result ? result[3] : false;}
var topVideo = getQueryParam("s");
var playerElement = document.getElementById("player");
var player = new Clappr.Player({
    height: "100%",
    width: "100%",
    flushLiveURLCache: false,
    poster: "",
    strings: {
                'id-ID': {
                    'live': 'Siaran Langsung',
                    'back_to_live': 'Jaringan sedang sibuk...',
                    'playback_not_supported': 'Browser anda tidak bisa memainkan video, coba dengan browser berbeda!'
                }
            },
    hideMediaControl: false,
    autoPlay: true,
    exitFullscreenOnEnd: false,
    watermark: 'https://s3.amazonaws.com/fifocloud/live/branding/1820/14542078381820.png',
            watermarkLink: 'https://tv.mbahnunungonline.net',
            position: 'bottom-left',
            width: "100%",
            height: '100%',
    plugins: {'core': [LevelSelector]},

    hlsjsConfig: {xhrSetup: function(xhr, url) {xhr.withCredentials = false;}},
    playbackConfig: {crossorigin: 'use-credentials'}}); player.attachTo(playerElement);
player.load({source: topVideo, mimeType: 'application/x-mpegURL'});
player.play();
//]]>
</script>
<div class="clear"></div>
</body>
</html>