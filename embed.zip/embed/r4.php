<!DOCTYPE html>
<html lang="en">
<head><meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    
    <title>TV</title>
    <style>
           body {
               margin:0;
               padding:0;
           }
       </style>
    <link href="https://warningfm.github.io/v3/css/video-js.css?v=1.8" rel="stylesheet">
    <link href="https://cdn1.bintangtenggarafm.com/v3/js/videojs/videojs-hls-quality-selector.css" rel="stylesheet">
    <script src="https://cdn1.bintangtenggarafm.com/v3/js/videojs/output.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
    
</head>
<body bgcolor="transparent" text="white" topmargin="0" leftmargin="0" rightmargin="0">
<div align="center">
<video poster="../img/thumbs/rtv-stream-06c6dc.jpg" id="video-player" class="vembed-responsive-item video-js vjs-default-skin vjs-big-play-centered" height="340" width="596" controls preload="none" autoplay>
<source src="https://livetvhooq.akamaized.net/902d04d98a094dc6a78e73166d108e3d/ap-southeast-1/5493668622001/profile_1/chunklist.m3u8?hdnts=st=1572085873~exp=9007200826826864~acl=/902d04d98a094dc6a78e73166d108e3d/*/profile_1/chunklist.m3u8*~hmac=252a726bb20fdb977834f11d3b83aa67138e81da32ef16b763a871e5ed767748
" type="application/x-mpegURL" />

</video>
<script>video=videojs('video-player',{autoplay:true});video.hlsQualitySelector();</script>
</div>
</body>
</html>