<!DOCTYPE html>
<html lang="en">
    <head>
                <title>DAAITV Embed</title>
                <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <link rel="stylesheet" href="https://www.metube.id/cc-content/themes/default/css/reset.css" />
        <script src="https://www.metube.id/cc-content/themes/default/jwplayer/jwplayer.js?v=6"></script>
        <script src="https://www.metube.id/cc-content/themes/default/jwplayer/jwplayer.compatibility.js"></script>
        <script src="https://www.metube.id/cc-content/themes/default/js/jquery.min.js"></script>
        <script>jwplayer.key = "9dOyFG96QFb9AWbR+FhhislXHfV1gIhrkaxLYfLydfiYyC0s";</script>
        <style type="text/css">
            html, body, .video-unavailable, video, img, .video-js {
                width:100% !important;
                height:100% !important;
                overflow:hidden;
            }
            .video-unavailable {
                background-color:#000;
                text-align:center;
                color:#FFF;
                font-size:16px;
                font-family:arial,helvetica,sans-serif;
            }
            .video-unavailable p {
                padding:50px;
                line-height:1.5em;
            }
                        .jw-icon-next {
                display: none !important;
            }
                    </style>
    <body>
        <script>
  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');

  ga('create', 'UA-85299917-1', 'auto');
  ga('require', 'linkid');
        ga('set', 'dimension1', '0');
    ga('set', 'dimension2', '1540319328.3042');
    ga('send', 'pageview');

</script>        
            <div id="myElement"></div>
            <script>
                jwplayer('myElement').setup({
                                        playlist: [{
                            file: 'https://edge.nim.mivo.tv/daaitv/daaitv2_all/playlist.m3u8',
                            image: "https://images-channel.mivo.com/channel/image/15/img-live-daaitv.jpg",
                            title: 'DAAITV',
                            mediaid: '1'
                        }, {
                            file: '',
                            image: "https://images-channel.mivo.com/channel/image/15/img-live-daaitv.jpg",
                            title: 'DAAITV',
                            mediaid: '2'
                        }, {
                            file: '',
                            image: "https://images-channel.mivo.com/channel/image/15/img-live-daaitv.jpg",
                            title: 'DAAITV',
                            mediaid: '3'
                        }, {
                            file: '',
                            image: "https://images-channel.mivo.com/channel/image/15/img-live-daaitv.jpg",
                            title: 'DAAITV',
                            mediaid: '4'
                        }, {
                            file: '',
                            image: "https://images-channel.mivo.com/channel/image/15/img-live-daaitv.jpg",
                            title: 'DAAITV',
                            mediaid: '5'
                        }],
                                        width: "100%",
                    aspectratio: "16:9",
                    abouttext: 'Design by : mbah nunung Online',
                                        stretching: "exactfit",
                                                            aboutlink: 'https://www.metube.id',
                    autostart: true,
                    androidhls: true,
                    displaydescription: true,
                    displaytitle: true,
                    visualplaylist: false,
                    skin: {"active": "#DF2148", "inactive": "#CCCCCC", "name": "glow"},
                    plugins: {
                                            "https://www.metube.id/cc-content/themes/default/js/ping.js": {"pixel": "http://content.jwplatform.com/ping.gif"}
                    },
                                                            advertising: {
                      client: "googima",
                      schedule: {
                        preroll: {
                          offset: "pre",
                          tag: "https://pubads.g.doubleclick.net/gampad/ads?sz=640x480&iu=/21705426382/1.1&impl=s&gdfp_req=1&env=vp&output=vast&unviewed_position_start=1&url=https%3A%2F%2Fwww.metube.id%2Flive%2FRCTI&description_url=https%3A%2F%2Fwww.metube.id%2Flive%2FRCTI&cust_params=Live%3D1"
                        }
                      }
                    },
                                        ga: {
                                                "idstring": "RCTI",
                        "label": "1"
                                            }
                });
                jwplayer('myElement').on('error', function () {
                                    if (jwplayer('myElement').getPlaylistIndex() >= (jwplayer('myElement').getPlaylist().length - 1)) {
                        $('#player-play').html('<img width="100%" height="431.44" src="https://www.metube.id/cc-content/themes/default/images/metube_error_player.jpg" alt="meTube error player"/>');
                    } else {
                        jwplayer('myElement').next();
                    }
                                });
                jwplayer('myElement').on('play', function () {
                                     });
                
            </script>
            <!-- END VIDEO -->

        
    </body>
</html>