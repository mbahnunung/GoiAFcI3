<!DOCTYPE html>
<html lang="en">
<head>
    <script async src="https://www.googletagmanager.com/gtag/js"></script>
    <title>mbah nunung Online</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="refresh" content="7200">
    <link rel="shortcut icon" type="images/x-icon" href="favicon.ico?ver=1530615553" />
    <link href="//vjs.zencdn.net/7.3.0/video-js.min.css" rel="stylesheet">
<style>
.video-js .vjs-menu-button-inline.vjs-slider-active,.video-js .vjs-menu-button-inline:focus,.video-js .vjs-menu-button-inline:hover,.video-js.vjs-no-flex .vjs-menu-button-inline {
    width: 10em
}

.video-js .vjs-controls-disabled .vjs-big-play-button {
    display: none!important
}

.video-js .vjs-control {
    width: 3em
}

.video-js .vjs-menu-button-inline:before {
    width: 1.5em
}

.vjs-menu-button-inline .vjs-menu {
    left: 3em
}

.vjs-paused.vjs-has-started.video-js .vjs-big-play-button,.video-js.vjs-ended .vjs-big-play-button,.video-js.vjs-paused .vjs-big-play-button {
    display: block
}

.video-js .vjs-load-progress div,.vjs-seeking .vjs-big-play-button,.vjs-waiting .vjs-big-play-button {
    display: none!important
}

.video-js .vjs-mouse-display:after,.video-js .vjs-play-progress:after {
    padding: 0 .4em .3em
}

.video-js.vjs-ended .vjs-loading-spinner {
    display: none;
}

.video-js.vjs-ended .vjs-big-play-button {
    display: block !important;
}

video-js.vjs-ended .vjs-big-play-button,.video-js.vjs-paused .vjs-big-play-button,.vjs-paused.vjs-has-started.video-js .vjs-big-play-button {
    display: block
}

.video-js .vjs-big-play-button {
    top: 50%;
    left: 50%;
    margin-left: -1.5em;
    margin-top: -1em
}

.video-js .vjs-big-play-button {
    background-color: rgba(0,0,0,0.35);
    font-size: 3.5em;
    border-radius: 50%;
    height: 2em !important;
    line-height: 2em !important;
    margin-top: -1em !important
}

.video-js:hover .vjs-big-play-button,.video-js .vjs-big-play-button:focus,.video-js .vjs-big-play-button:active {
    background-color: rgba(0,0,0,0.35)
}

.video-js .vjs-loading-spinner {
    border-color: rgba(255,255,255,0.7)
}

.video-js .vjs-control-bar2 {
    background-color: transparent
}

.video-js .vjs-control-bar {
    background-color: rgba(0,0,0,0) !important;
    color: #ffffff;
    font-size: 18px
}

.video-js .vjs-play-progress,.video-js  .vjs-volume-level {
    background-color: #2483d5
}

.video-js .vjs-big-play-button {
    height: 2em !important;
    width: 2em !important;
    line-height: 1.9em !important;
    margin-top: -1em !important;
    margin-left: -1em;
    border-width: 3px
}

.video-js .vjs-icon-play:before, .video-js .vjs-big-play-button:before {
    font-size: 50px;
}

.video-js  .vjs-progress-holder {
    font-size: 1.7em;
    border-radius: 10px;
}

.video-js .vjs-progress-holder .vjs-play-progress, .video-js .vjs-progress-holder .vjs-load-progress, .video-js .vjs-progress-holder .vjs-load-progress div, .video-js .vjs-slider,.vjs-volume-level {
    border-radius: 10px;
}

.video-js .vjs-load-progress {
    background: rgba(255,255,255,0.5);
}
.videoWrapper {
	position: relative;
	padding-bottom: 56.25%; /* 16:9 */
	padding-top: 25px;
	height: 0;
}
.videoWrapper video {
	position: absolute;
	top: 0;
	left: 0;
	width: 100%;
	height: 100%;
}
</style>
<style>
           body {
               margin:0;
               padding:0;
               overflow: hidden;
           }
       </style>
</head>
<body class="desktop">

		
  <script src="//vjs.zencdn.net/7.3.0/video.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/videojs-contrib-hls/3.0.2/videojs-contrib-hls.js"></script>
  <script src="//unpkg.com/videojs-contrib-quality-levels@2.0.3/dist/videojs-contrib-quality-levels.min.js"></script>
  <script src="//unpkg.com/videojs-hls-quality-selector@1.0.5/dist/videojs-hls-quality-selector.min.js"></script>
 <video id="player" class="video-js vjs-default-skin vjs-16-9" controls preload="auto" width="100%"  poster="https://sbo.co.id/videos/stid.png" 
 data-setup="{}">
    <source src="https://aja-hd-web-hls-live.secure.footprint.net/egress/chandler/aljazeera2/arabichd/index.m3u8" type="application/x-mpegURL">
  </video>	
		
<script>
        var player = videojs('#player');
        player.hlsQualitySelector();
    </script>
</body>
</html>