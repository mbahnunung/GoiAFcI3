<meta name="robots" content="noindex"/>
<style>body{margin:0;padding:0;}</style>
<link type='text/css' rel='stylesheet' href='https://cdn1.mbahnunungonline.net/css/dist/v7/jwplayer.css' />
<link type='text/css' rel='stylesheet' href='https://cdn1.mbahnunungonline.net/css/dist/v7/player.css' />
<style type="text/css">
        body { margin:0 auto; padding:0; background:#2f3542; overflow: hidden; }
        #title { font:bold 24px/36px Arial, sans-serif; color:#000; margin:40px auto 10px auto; display:none; text-shadow:#FFF 2px 2px 0; }
        #description { font:13px/20px Arial, sans-serif; margin:15px auto; display:none; text-shadow:#FFF 1px 1px 0; }
    </style>
<script src="//ssl.p.jwpcdn.com/player/v/8.2.2/jwplayer.js?v=1.1.0.0.222"></script>
<script>jwplayer.key = "9dOyFG96QFb9AWbR+FhhislXHfV1gIhrkaxLYfLydfiYyC0s";</script>
<div id="streaming"></div>
<script type="text/javascript">
var meta = document.createElement('meta');
meta.name = "referrer";
meta.content = "no-referrer";
document.getElementsByTagName('head')[0].appendChild(meta); 
    jwplayer("streaming").setup({
		primary : 'html5',
		width: '100%',
		height: '100%',
		skin: {"active": "#DF2148", "inactive": "#CCCCCC", "name": "glow"},
		abouttext: 'Design by : mbah nunung Online',
		aboutlink: 'http://mbahnunungonline.net',
		autostart: 'true',
		file: "http://rtm1mobile.secureswiftcontent.com/Origin02/ngrp:RTM2/playlist.m3u8",
		title: "TV Okey",
		image: "https://4.bp.blogspot.com/-BJpbb1Wxc8M/XMK1ZG2aucI/AAAAAAAALVw/92dEplccyMUliAlaktqK7ka0xUyjOI3nQCLcBGAs/s1600/TV_Okey_RTM.png?v=8.3.2"
	});
	jwplayer().onError(function(){
		jwplayer().load({
			file: "https://rtm-live-stream1.glueapi.io/smil:rtmch003.smil/playlist.m3u8",
			title: "TV Okey",
			//image:""
		});jwplayer().play();
		jwplayer().onError(function(){
			jwplayer("streaming").setup({
				primary: "html5",
				file: "https://rtm-live-stream1.glueapi.io/smil:rtmch003.smil/playlist.m3u8",
				title: "TV Okey",
				//image:""
			});			
			jwplayer("streaming").setup({
				primary: "html5",
				file: "https://rtm-live-stream1.glueapi.io/smil:rtmch003.smil/playlist.m3u8",
				title: "TV Okey",
				//image:""
			});			
			jwplayer().onError(function(){
				jwplayer("streaming").setup({
					title: "TV Okey",
					file:"https://edge.nim.mivo.tv/video/assets/oops.m3u8",
					image:"error.jpg"
				});
			});	
		});
	});
</script>